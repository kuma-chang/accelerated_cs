class Example {
  public static void main (String argv[]) {
    int n = Integer.parseInt(argv[0]);
    for (int i = 0; i < n; i++)
	System.out.println(Integer.toString(i) +  ": " + argv[1]);
  }
}



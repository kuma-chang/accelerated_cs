abstract class Exp {
  abstract void emit(Env<Integer> env, int depth) throws Env.UndefinedId ;
}


    

abstract class Exp {
  abstract int eval();

	abstract void emit();
}


    

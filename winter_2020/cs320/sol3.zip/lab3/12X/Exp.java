abstract class Exp {
  abstract int eval();
}


    

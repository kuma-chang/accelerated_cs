#ifndef hw1_plinko_h
#define hw1_plinko_h

#include <stdio.h>
#include <string.h>

//include the .h that were given
#include "hw1given.h"






#endif
